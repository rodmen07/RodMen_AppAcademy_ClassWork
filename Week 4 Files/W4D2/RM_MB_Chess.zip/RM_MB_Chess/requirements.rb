require_relative 'piece.rb'
require_relative "nullpiece.rb"
require_relative "rook_bishop_queen.rb"
require "byebug"